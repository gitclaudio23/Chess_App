const socket = io();
let selectedCell = null;

socket.on('connect', () => {
    console.log('Connected to server');
    fetchGameStatus();
});

socket.on('move_made', (data) => {
    updateBoard(data.board);
});

socket.on('game_restarted', (data) => {
    updateBoard(data.board);
});

document.getElementById('restart').addEventListener('click', () => {
    fetch('/restart', { method: 'POST' })
        .then(response => response.json())
        .then(data => {
            console.log(data.message);
        });
});

function fetchGameStatus() {
    fetch('/game')
        .then(response => response.json())
        .then(data => {
            updateBoard(data.board);
        });
}

function updateBoard(board) {
    const boardDiv = document.getElementById('board');
    boardDiv.innerHTML = '';
    for (let y = 0; y < board.length; y++) {
        for (let x = 0; x < board[y].length; x++) {
            const cellDiv = document.createElement('div');
            cellDiv.className = 'cell';
            cellDiv.textContent = getChessPieceSymbol(board[y][x]);
            cellDiv.dataset.position = `${String.fromCharCode(97 + x)}${8 - y}`;
            cellDiv.addEventListener('click', () => onCellClick(cellDiv));
            boardDiv.appendChild(cellDiv);
        }
    }
}

function getChessPieceSymbol(piece) {
    const symbols = {
        "r": "♜", "n": "♞", "b": "♝", "q": "♛", "k": "♚", "p": "♟",
        "R": "♖", "N": "♘", "B": "♗", "Q": "♕", "K": "♔", "P": "♙"
    };
    return symbols[piece] || "";
}

function onCellClick(cell) {
    if (selectedCell) {
        const move = [selectedCell.dataset.position, cell.dataset.position];
        fetch('/move', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ move })
        }).then(response => response.json())
          .then(data => {
              console.log(data.message);
              fetchGameStatus();
          });
        selectedCell = null;
    } else {
        selectedCell = cell;
        cell.classList.add('selected');
    }
}
