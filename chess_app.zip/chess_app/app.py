from flask import Flask, request, jsonify, render_template
from flask_socketio import SocketIO, emit
from game import game_instance

app = Flask(__name__)
socketio = SocketIO(app)

# REST API Endpoint

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/game', methods=['GET'])
def get_game_status():
    try:
        status = game_instance.get_status()
        return jsonify(status)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/move', methods=['POST'])
def make_move():
    try:
        data = request.json
        move = data.get('move')
        if not move:
            raise ValueError("Move is required")
        game_instance.make_move(move)
        socketio.emit('move_made', game_instance.get_status())
        return jsonify({'message': 'Move made successfully'})
    except ValueError as ve:
        return jsonify({'error': str(ve)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/restart', methods=['POST'])
def restart_game():
    try:
        game_instance.__init__()
        socketio.emit('game_restarted', game_instance.get_status())
        return jsonify({'message': 'Game restarted successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# WebSocket events

@socketio.on('connect')
def handle_connect():
    emit('connected', {'message': 'Connected to the server'})

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

# Security and Error Handling
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not Found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal Server Error'}), 500

if __name__ == '__main__':
    socketio.run(app, debug=True)
