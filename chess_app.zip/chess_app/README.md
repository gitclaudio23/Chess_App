# Chess Game API

## API Endpoints

### 1. GET /game
- Description: Mendapatkan status permainan saat ini.
- Response:
  - 200 OK: Mengembalikan status permainan.
  - 500 Internal Server Error: Jika terjadi kesalahan.

### 2. POST /move
- Description: Melakukan pergerakan dalam permainan.
- Request Body:
  ```json
  {
    "move": [(start_pos), (end_pos)]
  }
