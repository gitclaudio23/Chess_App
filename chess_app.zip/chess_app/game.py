class ChessGame:
    def __init__(self):
        self.board = self.create_initial_board()
        self.turn = 'white'

    def create_initial_board(self):
        return [
            ["r", "n", "b", "q", "k", "b", "n", "r"],
            ["p", "p", "p", "p", "p", "p", "p", "p"],
            ["", "", "", "", "", "", "", ""],
            ["", "", "", "", "", "", "", ""],
            ["", "", "", "", "", "", "", ""],
            ["", "", "", "", "", "", "", ""],
            ["P", "P", "P", "P", "P", "P", "P", "P"],
            ["R", "N", "B", "Q", "K", "B", "N", "R"]
        ]

    def get_status(self):
        return {"board": self.board}

    def make_move(self, move):
        start, end = move
        start_x, start_y = self.convert_position(start)
        end_x, end_y = self.convert_position(end)
        if self.is_valid_move(start_x, start_y, end_x, end_y):
            self.board[end_y][end_x] = self.board[start_y][start_x]
            self.board[start_y][start_x] = ""
            self.switch_turn()

    def convert_position(self, pos):
        col = ord(pos[0]) - ord('a')
        row = 8 - int(pos[1])
        return col, row

    def is_valid_move(self, start_x, start_y, end_x, end_y):
        piece = self.board[start_y][start_x].lower()
        if piece == 'p':
            return self.is_valid_pawn_move(start_x, start_y, end_x, end_y)
        # Add more piece move validations here (rook, knight, bishop, queen, king)
        return True

    def is_valid_pawn_move(self, start_x, start_y, end_x, end_y):
        direction = 1 if self.board[start_y][start_x].isupper() else -1
        if start_x == end_x and self.board[end_y][end_x] == "":
            if start_y + direction == end_y:
                return True
            if (start_y == 1 and direction == 1) or (start_y == 6 and direction == -1):
                if start_y + 2 * direction == end_y and self.board[start_y + direction][start_x] == "":
                    return True
        return False

    def switch_turn(self):
        self.turn = 'white' if self.turn == 'black' else 'black'

game_instance = ChessGame()
